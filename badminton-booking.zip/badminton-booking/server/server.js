const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const mongoose = require('mongoose');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET = process.env.SECRET || 'badminton-secret-change-me';
const MONGO_URL = process.env.MONGO_URL || 'mongodb://127.0.0.1:27017/badminton';

const COURTS = [1, 2, 3, 4];
const SLOTS = ['13.00-14.00', '14.00-15.00'];
const ACTIVE = ['waiting', 'playing'];

const userSchema = new mongoose.Schema({
  username: { type: String, unique: true, required: true },
  name: { type: String, required: true },
  salt: String,
  hash: String,
  role: { type: String, enum: ['student', 'admin'], default: 'student' }
});
const bookingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  userName: String,
  court: Number,
  date: String,
  slot: String,
  status: { type: String, enum: ['waiting', 'playing', 'done', 'cancelled'], default: 'waiting' },
  createdAt: { type: Date, default: Date.now }
});
const User = mongoose.model('User', userSchema);
const Booking = mongoose.model('Booking', bookingSchema);

const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');

async function seedAdmin() {
  if (await User.exists({ role: 'admin' })) return;
  const salt = crypto.randomBytes(16).toString('hex');
  await User.create({ username: 'admin', name: 'Admin', salt, hash: hashPw('admin1234', salt), role: 'admin' });
  console.log('สร้างบัญชี Admin แล้ว  ->  admin / admin1234');
}

mongoose.connect(MONGO_URL)
  .then(() => { console.log('MongoDB connected'); return seedAdmin(); })
  .catch(err => console.error('MongoDB error:', err.message));

app.use(express.json());
app.use(cookieParser(SECRET));                       // Cookies
app.use(session({                                    // Session
  secret: SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, maxAge: 1000 * 60 * 60 * 2 }
}));
app.use('/css', express.static(path.join(__dirname, '..', 'public/css')));
app.use('/js', express.static(path.join(__dirname, '..', 'public/js')));
app.use('/img', express.static(path.join(__dirname, '..', 'public/img')));

// Cookie: จำว่าเคย login แล้ว -> สร้าง Session ให้อัตโนมัติ
app.use(async (req, res, next) => {
  try {
    if (!req.session.user && req.signedCookies.remember) {
      const u = await User.findById(req.signedCookies.remember);
      if (u) req.session.user = { id: u._id.toString(), name: u.name, username: u.username, role: u.role };
    }
  } catch (e) { /* ignore */ }
  next();
});

const needLoginPage = (req, res, next) => (req.session.user ? next() : res.redirect('/login'));
const needAdminPage = (req, res, next) =>
  req.session.user && req.session.user.role === 'admin' ? next() : res.redirect('/home');
const needLogin = (req, res, next) => (req.session.user ? next() : res.status(401).json({ message: 'กรุณาเข้าสู่ระบบ' }));
const needAdmin = (req, res, next) =>
  req.session.user && req.session.user.role === 'admin' ? next() : res.status(403).json({ message: 'เฉพาะ Admin' });

const view = f => (req, res) => res.sendFile(path.join(__dirname, '..', 'views', f));
app.get('/', (req, res) => res.redirect(req.session.user ? '/home' : '/login'));
app.get('/login', (req, res) => (req.session.user ? res.redirect('/home') : view('login.html')(req, res)));
app.get('/register', view('register.html'));
app.get('/home', needLoginPage, view('home.html'));
app.get('/my-bookings', needLoginPage, view('my-bookings.html'));
app.get('/admin', needAdminPage, view('admin.html'));

app.post('/api/register', async (req, res) => {
  const { username, name, password } = req.body;
  if (!username || !name || !password || password.length < 4)
    return res.status(400).json({ message: 'กรอกข้อมูลให้ครบ (รหัสผ่านอย่างน้อย 4 ตัว)' });
  if (await User.exists({ username })) return res.status(409).json({ message: 'ชื่อผู้ใช้นี้ถูกใช้แล้ว' });
  const salt = crypto.randomBytes(16).toString('hex');
  await User.create({ username, name, salt, hash: hashPw(password, salt) });
  res.status(201).json({ message: 'สมัครสมาชิกสำเร็จ' });
});

// Login
app.post('/api/login', async (req, res) => {
  const { username, password, remember } = req.body;
  const u = await User.findOne({ username });
  if (!u || hashPw(password || '', u.salt) !== u.hash)
    return res.status(401).json({ message: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
  req.session.user = { id: u._id.toString(), name: u.name, username: u.username, role: u.role };
  if (remember) res.cookie('remember', u._id.toString(), { signed: true, httpOnly: true, maxAge: 1000 * 60 * 60 * 24 * 7 });
  res.json({ message: 'เข้าสู่ระบบสำเร็จ', role: u.role });
});

// Logout
app.post('/api/logout', (req, res) => {
  res.clearCookie('remember');
  req.session.destroy(() => res.json({ message: 'ออกจากระบบแล้ว' }));
});

// ข้อมูลผู้ใช้จาก Session
app.get('/api/me', needLogin, (req, res) => res.json(req.session.user));

app.get('/api/courts', needLogin, async (req, res) => {
  const date = req.query.date;
  const list = await Booking.find({ date, status: { $in: ACTIVE } }).sort({ createdAt: 1 });
  const courts = COURTS.map(c => ({
    court: c,
    slots: SLOTS.map(s => ({
      slot: s,
      queue: list.filter(b => b.court === c && b.slot === s)
        .map((b, i) => ({ no: i + 1, userName: b.userName, status: b.status }))
    }))
  }));
  res.json({ slots: SLOTS, courts });
});

app.post('/api/bookings', needLogin, async (req, res) => {
  const { court, date, slot } = req.body;
  const today = new Date().toISOString().slice(0, 10);
  if (!COURTS.includes(Number(court)) || !SLOTS.includes(slot) || !date || date < today)
    return res.status(400).json({ message: 'ข้อมูลการจองไม่ถูกต้อง' });
  const dup = await Booking.exists({ user: req.session.user.id, court, date, slot, status: { $in: ACTIVE } });
  if (dup) return res.status(409).json({ message: 'คุณจองช่วงเวลานี้ไว้แล้ว' });
  const b = await Booking.create({ user: req.session.user.id, userName: req.session.user.name, court, date, slot });
  const no = await Booking.countDocuments({ court, date, slot, status: { $in: ACTIVE }, createdAt: { $lte: b.createdAt } });
  res.status(201).json({ message: `จองสำเร็จ คุณเป็นคิวที่ ${no}`, queueNo: no });
});

app.get('/api/bookings/mine', needLogin, async (req, res) => {
  const list = await Booking.find({ user: req.session.user.id }).sort({ createdAt: -1 });
  const out = [];
  for (const b of list) {
    let queueNo = null;
    if (ACTIVE.includes(b.status))
      queueNo = await Booking.countDocuments({
        court: b.court, date: b.date, slot: b.slot, status: { $in: ACTIVE }, createdAt: { $lte: b.createdAt }
      });
    out.push({ id: b._id, court: b.court, date: b.date, slot: b.slot, status: b.status, queueNo });
  }
  res.json(out);
});

app.patch('/api/bookings/:id/cancel', needLogin, async (req, res) => {
  const b = await Booking.findOne({ _id: req.params.id, user: req.session.user.id });
  if (!b) return res.status(404).json({ message: 'ไม่พบการจอง' });
  if (b.status !== 'waiting') return res.status(400).json({ message: 'ยกเลิกได้เฉพาะคิวที่รออยู่' });
  b.status = 'cancelled';
  await b.save();
  res.json({ message: 'ยกเลิกการจองแล้ว' });
});

app.get('/api/admin/bookings', needAdmin, async (req, res) => {
  const filter = req.query.date ? { date: req.query.date } : {};
  const list = await Booking.find(filter).sort({ date: 1, court: 1, slot: 1, createdAt: 1 });
  res.json(list.map(b => ({ id: b._id, userName: b.userName, court: b.court, date: b.date, slot: b.slot, status: b.status })));
});

app.patch('/api/admin/bookings/:id', needAdmin, async (req, res) => {
  const { status } = req.body;
  if (!['waiting', 'playing', 'done', 'cancelled'].includes(status))
    return res.status(400).json({ message: 'สถานะไม่ถูกต้อง' });
  const b = await Booking.findByIdAndUpdate(req.params.id, { status }, { new: true });
  if (!b) return res.status(404).json({ message: 'ไม่พบการจอง' });
  res.json({ message: 'อัปเดตสถานะแล้ว' });
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
